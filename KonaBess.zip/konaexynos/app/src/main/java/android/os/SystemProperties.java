package android.os;

@SuppressWarnings({"unused", "RedundantSuppression"})
public class SystemProperties {
    public static String get(String key, String def) {
        throw new RuntimeException("Stub!");
    }
}